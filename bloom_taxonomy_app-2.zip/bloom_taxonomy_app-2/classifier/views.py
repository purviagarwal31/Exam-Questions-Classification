from django.shortcuts import render
from .nlp_classifier import classify_question  # Import the function from nlp_classifier.py

def index(request):
    if request.method == 'POST':
        input_text = request.POST.get('question')  # Get input from form
        result = classify_question(input_text)  # Process input
        return render(request, 'index.html', {'question_text': input_text, 'result': result})  # Pass result to template
    return render(request, 'index.html')

