from django.db import models

class ExamQuestion(models.Model):
    # Your fields here
    text = models.TextField()
    # other fields

# In classifier/models.py
def classify_input(text):
    # Implement your classification logic here
    return f"Classified result for: {text}"



