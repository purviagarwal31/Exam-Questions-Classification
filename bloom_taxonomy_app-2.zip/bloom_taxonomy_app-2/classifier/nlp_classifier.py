import pandas as pd
import nltk
import string
import joblib
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from sklearn.calibration import label_binarize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB, BernoulliNB, ComplementNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, roc_auc_score, roc_curve, confusion_matrix
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

def load_dataset():
    return pd.read_csv('dataset.csv')

def clean_text(text):
    text = str(text).lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    tokens = word_tokenize(text)
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [WordNetLemmatizer().lemmatize(word) for word in tokens if word not in stop_words]
    return ' '.join(filtered_tokens)

from sklearn.metrics import confusion_matrix

def build_and_evaluate_model(X_train, X_test, y_train, y_test, model, model_name, le):
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    metrics = {
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred, average='weighted'),
        'recall': recall_score(y_test, y_pred, average='weighted'),
        'f1_score': f1_score(y_test, y_pred, average='weighted'),
        'error_rate': 1 - accuracy_score(y_test, y_pred),
    }

    target_names = [str(label) for label in le.classes_]
    print(f"Performance Metrics for {model_name}:\n{classification_report(y_test, y_pred, target_names=target_names)}")

    metrics['confusion_matrix'] = confusion_matrix(y_test, y_pred)
    
    y_test_bin = label_binarize(y_test, classes=np.arange(len(le.classes_)))
    try:
        y_pred_proba = model.predict_proba(X_test)
        metrics['roc_auc'] = roc_auc_score(y_test_bin, y_pred_proba, average='weighted', multi_class='ovr')
        metrics['fpr'], metrics['tpr'], _ = roc_curve(y_test_bin.ravel(), y_pred_proba.ravel())
    except AttributeError:
        metrics['roc_auc'] = metrics['fpr'] = metrics['tpr'] = None

    return metrics



def train_and_save_model():
    df = load_dataset()
    df['Exam Questions'] = df['Exam Questions'].apply(clean_text)
    X = df['Exam Questions']
    y = df["Bloom's Taxonomy Level"]

    vectorizer = TfidfVectorizer(ngram_range=(1, 2), stop_words='english')
    X_transformed = vectorizer.fit_transform(X)

    le = LabelEncoder()
    y_encoded = le.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(X_transformed, y_encoded, test_size=0.2, random_state=42)

    models = {
        'Multinomial NB': MultinomialNB(),
        'Bernoulli NB': BernoulliNB(),
        'Complement NB': ComplementNB(),
        'KNN': KNeighborsClassifier(n_neighbors=5),
        'Decision Tree': DecisionTreeClassifier(max_depth=10, random_state=42),
        'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
        'SVC': SVC(kernel='rbf', random_state=42, probability=True)
    }

    metrics = {name: build_and_evaluate_model(X_train, X_test, y_train, y_test, model, name, le) for name, model in models.items()}

    best_model_name = max(metrics, key=lambda x: metrics[x]['accuracy'])
    best_model = models[best_model_name]

    joblib.dump(best_model, 'best_model.pkl')
    joblib.dump(vectorizer, 'vectorizer.pkl')
    joblib.dump(le, 'label_encoder.pkl')

    print(f"Best model: {best_model_name}")
    print(f"Performance: {metrics[best_model_name]}")

    for name, model_metrics in metrics.items():
        plot_confusion_matrix(model_metrics['confusion_matrix'], name, [str(label) for label in le.classes_])

    plot_performance_metrics(metrics)
    plot_roc_curve(metrics, models.keys())


def plot_performance_metrics(metrics):
    model_names = list(metrics.keys())
    values = {metric: [metrics[name][metric] for name in model_names] for metric in ['accuracy', 'precision', 'recall', 'f1_score', 'error_rate']}
    
    x = np.arange(len(model_names))
    width = 0.15

    plt.figure(figsize=(16, 10))
    for i, metric in enumerate(values.keys()):
        plt.bar(x + i * width - 2 * width, values[metric], width, label=metric.capitalize())

    plt.xlabel('Models')
    plt.ylabel('Scores')
    plt.title('Model Performance Metrics Comparison')
    plt.xticks(x, model_names)
    plt.legend()
    plt.show()
    plt.savefig('classifier/static/classifier/plots/metrics_comparison.png')
    plt.close()
   

import os

import seaborn as sns
import matplotlib.pyplot as plt

def plot_confusion_matrix(conf_matrix, model_name, target_names):
    # Ensure the directory exists
    output_dir = 'classifier/static/classifier/plots'
    os.makedirs(output_dir, exist_ok=True)
    
    plt.figure(figsize=(10, 7))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=target_names, yticklabels=target_names)
    plt.xlabel('Predicted Labels')
    plt.ylabel('True Labels')
    plt.title(f'Confusion Matrix for {model_name}')
    # Save the plot
    file_path = os.path.join(output_dir, f'confusion_matrix_{model_name}.png')
    plt.savefig(file_path)
    plt.close()
   

def plot_roc_curve(metrics, model_names):
    plt.figure(figsize=(12, 8))
    for model_name in model_names:
        if metrics[model_name]['fpr'] is not None and metrics[model_name]['tpr'] is not None:
            plt.plot(metrics[model_name]['fpr'], metrics[model_name]['tpr'], marker='o', label=f"{model_name} (AUC = {metrics[model_name]['roc_auc']:.2f})")
    
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve Comparison')
    plt.legend(loc='best')
    plt.savefig('classifier/static/classifier/plots/roc_curves.png')
    plt.close()

def load_model():
    return joblib.load('best_model.pkl'), joblib.load('vectorizer.pkl'), joblib.load('label_encoder.pkl')

def classify_question(text):
    model, vectorizer, le = load_model()
    input_text = vectorizer.transform([clean_text(text)])
    prediction = model.predict(input_text)
    return le.inverse_transform(prediction)[0]

train_and_save_model()
